#ifndef _WAV_H
#define _WAV_H

//int wav_scan(ScanData s);

#endif // _WAV_H
