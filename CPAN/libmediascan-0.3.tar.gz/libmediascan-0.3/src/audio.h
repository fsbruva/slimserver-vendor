#ifndef _AUDIO_H
#define _AUDIO_H

MediaScanAudio *audio_create(void);

void audio_destroy(MediaScanAudio *a);

#endif // _AUDIO_H
